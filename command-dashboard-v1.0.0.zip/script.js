const searchInput = document.getElementById("searchbox");
const engine = document.getElementById("engine");
const engineStatus = document.getElementById("engineStatus");
const clock = document.getElementById("clock");
const colorPicker = document.getElementById("colorPicker");
const hexInput = document.getElementById("hexInput");
const hexError = document.getElementById("hexError");
const customizer = document.getElementById("customizer");
const themeButton = document.getElementById("themeButton");
const resetColor = document.getElementById("resetColor");

const DEFAULT_COLOR = "#ff003c";
const DEFAULT_ENGINE = "google";

function isValidHex(hex) {
    return /^#?[0-9A-Fa-f]{6}$/.test(hex);
}

function hexToRgb(hex) {
    hex = hex.replace("#", "");
    const number = parseInt(hex, 16);
    const r = (number >> 16) & 255;
    const g = (number >> 8) & 255;
    const b = number & 255;
    return `${r}, ${g}, ${b}`;
}

function updateHexField(color) {
    hexInput.value = color.replace("#", "").toUpperCase();
}

function applyTheme(color) {
    if (!isValidHex(color)) {
        return;
    }

    if (!color.startsWith("#")) {
        color = "#" + color;
    }

    document.documentElement.style.setProperty("--accent", color);
    document.documentElement.style.setProperty("--accent-rgb", hexToRgb(color));

    colorPicker.value = color;
    updateHexField(color);

    localStorage.setItem("dashboardAccent", color);

    hexError.textContent = "Theme color applied";
    hexError.classList.remove("invalid");
    hexError.classList.add("valid");
}

colorPicker.addEventListener("input", (event) => {
    applyTheme(event.target.value);
});

hexInput.addEventListener("input", (event) => {
    let value = event.target.value
        .replace("#", "")
        .replace(/[^0-9a-fA-F]/g, "")
        .slice(0, 6);

    event.target.value = value.toUpperCase();

    if (value.length === 6) {
        applyTheme("#" + value);
    } else {
        hexError.textContent = "Enter a 6-digit HEX value";
        hexError.classList.remove("valid");
        hexError.classList.add("invalid");
    }
});

hexInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") {
        return;
    }

    const value = hexInput.value.trim();

    if (isValidHex(value)) {
        applyTheme(value.startsWith("#") ? value : "#" + value);
    }
});

document.querySelectorAll(".preset").forEach((button) => {
    button.addEventListener("click", () => {
        applyTheme(button.dataset.color);
    });
});

resetColor.addEventListener("click", () => {
    applyTheme(DEFAULT_COLOR);
});

const savedColor = localStorage.getItem("dashboardAccent");

if (savedColor && isValidHex(savedColor)) {
    applyTheme(savedColor);
} else {
    applyTheme(DEFAULT_COLOR);
}

themeButton.addEventListener("click", (event) => {
    event.stopPropagation();
    customizer.classList.toggle("open");
});

document.addEventListener("click", (event) => {
    if (!customizer.contains(event.target) && event.target !== themeButton) {
        customizer.classList.remove("open");
    }
});

function searchWeb() {
    const query = searchInput.value.trim();

    if (!query) {
        searchInput.focus();

        searchInput.animate(
            [
                { transform: "translateX(0)" },
                { transform: "translateX(-6px)" },
                { transform: "translateX(6px)" },
                { transform: "translateX(0)" }
            ],
            { duration: 200 }
        );

        return;
    }

    const encoded = encodeURIComponent(query);

    const searchURLs = {
        google: `https://www.google.com/search?q=${encoded}`,
        bing: `https://www.bing.com/search?q=${encoded}`,
        duck: `https://duckduckgo.com/?q=${encoded}`,
        youtube: `https://www.youtube.com/results?search_query=${encoded}`
    };

    window.location.href = searchURLs[engine.value];
}

searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        searchWeb();
    }
});

engine.addEventListener("change", () => {
    engineStatus.textContent = engine.options[engine.selectedIndex].text;

    localStorage.setItem(
        "dashboardEngine",
        engine.value
    );
});

const savedEngine = localStorage.getItem("dashboardEngine");

engine.value = savedEngine || DEFAULT_ENGINE;

engineStatus.textContent =
    engine.options[engine.selectedIndex].text;

function updateClock() {
    const now = new Date();

    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");

    clock.textContent = `${hours}:${minutes}:${seconds}`;
}

updateClock();
setInterval(updateClock, 1000);

document.addEventListener("keydown", (event) => {
    if (
        event.key === "/" &&
        document.activeElement !== searchInput &&
        document.activeElement !== hexInput
    ) {
        event.preventDefault();
        searchInput.focus();
    }

    if (event.key === "Escape") {
        customizer.classList.remove("open");
        searchInput.blur();
        hexInput.blur();
    }
});

window.addEventListener("load", () => {
    setTimeout(() => {
        searchInput.focus();
    }, 300);
});
