Place KodeMono-Regular.ttf in this folder if you want the bundled Kode Mono font. The CSS will fall back to a generic monospace font if it is absent.
